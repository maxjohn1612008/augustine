const router = require('express').Router();
const { getDB } = require('../db');
const { authMiddleware, leaderOnly } = require('../middleware/auth');

const POINT_TYPES = {
  mass: 'mass_points',
  confession: 'confession_points',
  meeting: 'meeting_points',
  attendance: 'attendance_points',
};

// Add or subtract points
router.post('/update', authMiddleware, leaderOnly, (req, res) => {
  const { participant_id, type, points, notes } = req.body;
  
  if (!participant_id || !type || points === undefined) {
    return res.status(400).json({ error: 'بيانات ناقصة' });
  }
  
  const validTypes = ['mass', 'confession', 'meeting', 'manual_add', 'manual_subtract'];
  if (!validTypes.includes(type)) {
    return res.status(400).json({ error: 'نوع النقاط غير صحيح' });
  }
  
  const pointsNum = parseInt(points);
  if (isNaN(pointsNum) || pointsNum <= 0) {
    return res.status(400).json({ error: 'قيمة النقاط غير صحيحة' });
  }
  
  const db = getDB();
  const participant = db.prepare('SELECT * FROM participants WHERE id = ?').get(participant_id);
  if (!participant) return res.status(404).json({ error: 'المشترك غير موجود' });
  
  const isSubtract = type === 'manual_subtract';
  const pointsChange = isSubtract ? -pointsNum : pointsNum;
  const date = new Date().toISOString().split('T')[0];
  
  const updatePoints = db.transaction(() => {
    // Update specific category points if applicable
    const categoryField = POINT_TYPES[type];
    if (categoryField) {
      db.prepare(`UPDATE participants SET total_points = total_points + ?, ${categoryField} = ${categoryField} + ? WHERE id = ?`)
        .run(pointsChange, pointsChange, participant_id);
    } else {
      db.prepare('UPDATE participants SET total_points = total_points + ? WHERE id = ?')
        .run(pointsChange, participant_id);
    }
    
    db.prepare(
      'INSERT INTO points_log (participant_id, type, points_change, notes, leader_id, date) VALUES (?, ?, ?, ?, ?, ?)'
    ).run(participant_id, type, pointsChange, notes || null, req.user.id, date);
  });
  
  updatePoints();
  
  const updated = db.prepare(
    'SELECT id, name, total_points, attendance_points, mass_points, confession_points, meeting_points FROM participants WHERE id = ?'
  ).get(participant_id);
  
  res.json({ success: true, participant: updated, points_change: pointsChange });
});

// Get leaderboard
router.get('/leaderboard', authMiddleware, (req, res) => {
  const db = getDB();
  const leaderboard = db.prepare(
    'SELECT id, name, total_points, attendance_points, mass_points, confession_points, meeting_points FROM participants ORDER BY total_points DESC LIMIT 20'
  ).all();
  res.json(leaderboard);
});

module.exports = router;
