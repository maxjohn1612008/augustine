const router = require('express').Router();
const { getDB } = require('../db');
const { authMiddleware, leaderOnly } = require('../middleware/auth');
const { v4: uuidv4 } = require('uuid');

// Get all participants (leaders only)
router.get('/', authMiddleware, leaderOnly, (req, res) => {
  const db = getDB();
  const { search, sort } = req.query;
  
  let query = 'SELECT id, name, unique_code, total_points, attendance_points, mass_points, confession_points, meeting_points, created_at FROM participants';
  const params = [];
  
  if (search) {
    query += ' WHERE name LIKE ?';
    params.push(`%${search}%`);
  }
  
  query += sort === 'name' ? ' ORDER BY name ASC' : ' ORDER BY total_points DESC';
  
  const participants = db.prepare(query).all(...params);
  res.json(participants);
});

// Get single participant (leader or the participant themselves)
router.get('/:id', authMiddleware, (req, res) => {
  const db = getDB();
  const { id } = req.params;
  
  if (req.user.role === 'participant' && req.user.id !== parseInt(id)) {
    return res.status(403).json({ error: 'غير مصرح' });
  }
  
  const participant = db.prepare(
    'SELECT id, name, unique_code, total_points, attendance_points, mass_points, confession_points, meeting_points, created_at FROM participants WHERE id = ?'
  ).get(id);
  
  if (!participant) return res.status(404).json({ error: 'المشترك غير موجود' });
  res.json(participant);
});

// Add new participant (leaders only)
router.post('/', authMiddleware, leaderOnly, (req, res) => {
  const { name } = req.body;
  if (!name?.trim()) return res.status(400).json({ error: 'الاسم مطلوب' });
  
  const db = getDB();
  const uniqueCode = uuidv4();
  
  const result = db.prepare(
    'INSERT INTO participants (name, unique_code) VALUES (?, ?)'
  ).run(name.trim(), uniqueCode);
  
  const participant = db.prepare('SELECT * FROM participants WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json(participant);
});

// Update participant
router.put('/:id', authMiddleware, leaderOnly, (req, res) => {
  const { name } = req.body;
  const { id } = req.params;
  if (!name?.trim()) return res.status(400).json({ error: 'الاسم مطلوب' });
  
  const db = getDB();
  db.prepare('UPDATE participants SET name = ? WHERE id = ?').run(name.trim(), id);
  const participant = db.prepare(
    'SELECT id, name, unique_code, total_points, attendance_points, mass_points, confession_points, meeting_points FROM participants WHERE id = ?'
  ).get(id);
  
  res.json(participant);
});

// Delete participant (leaders only)
router.delete('/:id', authMiddleware, leaderOnly, (req, res) => {
  const db = getDB();
  db.prepare('DELETE FROM participants WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// Get participant attendance history
router.get('/:id/attendance', authMiddleware, (req, res) => {
  const { id } = req.params;
  if (req.user.role === 'participant' && req.user.id !== parseInt(id)) {
    return res.status(403).json({ error: 'غير مصرح' });
  }
  
  const db = getDB();
  const records = db.prepare(
    'SELECT * FROM attendance WHERE participant_id = ? ORDER BY date DESC, time DESC LIMIT 50'
  ).all(id);
  res.json(records);
});

// Get participant points log
router.get('/:id/points-log', authMiddleware, (req, res) => {
  const { id } = req.params;
  if (req.user.role === 'participant' && req.user.id !== parseInt(id)) {
    return res.status(403).json({ error: 'غير مصرح' });
  }
  
  const db = getDB();
  const logs = db.prepare(
    'SELECT pl.*, l.name as leader_name FROM points_log pl LEFT JOIN leaders l ON pl.leader_id = l.id WHERE pl.participant_id = ? ORDER BY pl.created_at DESC LIMIT 50'
  ).all(id);
  res.json(logs);
});

module.exports = router;
