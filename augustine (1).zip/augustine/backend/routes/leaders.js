const router = require('express').Router();
const bcrypt = require('bcryptjs');
const { getDB } = require('../db');
const { authMiddleware, leaderOnly } = require('../middleware/auth');

// Get all leaders
router.get('/', authMiddleware, leaderOnly, (req, res) => {
  const db = getDB();
  const leaders = db.prepare('SELECT id, username, name, created_at FROM leaders').all();
  res.json(leaders);
});

// Add new leader
router.post('/', authMiddleware, leaderOnly, (req, res) => {
  const { username, password, name } = req.body;
  if (!username || !password || !name) return res.status(400).json({ error: 'جميع الحقول مطلوبة' });
  
  const db = getDB();
  const exists = db.prepare('SELECT id FROM leaders WHERE username = ?').get(username);
  if (exists) return res.status(409).json({ error: 'اسم المستخدم موجود مسبقاً' });
  
  const hashed = bcrypt.hashSync(password, 12);
  const result = db.prepare('INSERT INTO leaders (username, password, name) VALUES (?, ?, ?)').run(username, hashed, name);
  
  res.status(201).json({ id: result.lastInsertRowid, username, name });
});

// Delete leader
router.delete('/:id', authMiddleware, leaderOnly, (req, res) => {
  const db = getDB();
  // Prevent deleting yourself
  if (parseInt(req.params.id) === req.user.id) {
    return res.status(400).json({ error: 'لا يمكن حذف حسابك الخاص' });
  }
  db.prepare('DELETE FROM leaders WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

module.exports = router;
