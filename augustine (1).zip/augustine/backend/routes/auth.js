const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { getDB } = require('../db');
const { JWT_SECRET } = require('../middleware/auth');

// Leader login
router.post('/login/leader', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'بيانات ناقصة' });
  
  const db = getDB();
  const leader = db.prepare('SELECT * FROM leaders WHERE username = ?').get(username);
  if (!leader) return res.status(401).json({ error: 'اسم المستخدم أو كلمة المرور غلط' });
  
  const valid = bcrypt.compareSync(password, leader.password);
  if (!valid) return res.status(401).json({ error: 'اسم المستخدم أو كلمة المرور غلط' });
  
  const token = jwt.sign({ id: leader.id, role: 'leader', name: leader.name }, JWT_SECRET, { expiresIn: '8h' });
  res.json({ token, name: leader.name, role: 'leader' });
});

// Participant login by unique code
router.post('/login/participant', (req, res) => {
  const { code } = req.body;
  if (!code) return res.status(400).json({ error: 'الكود مطلوب' });
  
  const db = getDB();
  const participant = db.prepare('SELECT * FROM participants WHERE unique_code = ?').get(code.trim());
  if (!participant) return res.status(401).json({ error: 'الكود غير صحيح' });
  
  const token = jwt.sign({ id: participant.id, role: 'participant', name: participant.name }, JWT_SECRET, { expiresIn: '24h' });
  res.json({ token, name: participant.name, role: 'participant', id: participant.id });
});

// Verify token
router.get('/verify', (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'لا يوجد token' });
  try {
    const user = jwt.verify(token, JWT_SECRET);
    res.json({ valid: true, user });
  } catch {
    res.status(401).json({ valid: false });
  }
});

module.exports = router;
