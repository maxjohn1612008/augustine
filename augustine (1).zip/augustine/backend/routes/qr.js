const router = require('express').Router();
const QRCode = require('qrcode');
const { getDB } = require('../db');
const { authMiddleware, leaderOnly } = require('../middleware/auth');

// Generate QR for a participant
router.get('/:participantId', authMiddleware, async (req, res) => {
  const db = getDB();
  const { participantId } = req.params;
  
  if (req.user.role === 'participant' && req.user.id !== parseInt(participantId)) {
    return res.status(403).json({ error: 'غير مصرح' });
  }
  
  const participant = db.prepare('SELECT * FROM participants WHERE id = ?').get(participantId);
  if (!participant) return res.status(404).json({ error: 'المشترك غير موجود' });
  
  try {
    const qrData = JSON.stringify({ 
      code: participant.unique_code, 
      name: participant.name,
      id: participant.id 
    });
    
    const qrDataURL = await QRCode.toDataURL(qrData, {
      width: 300,
      margin: 2,
      color: { dark: '#1a1a2e', light: '#ffffff' }
    });
    
    // Save QR to DB
    db.prepare('UPDATE participants SET qr_code = ? WHERE id = ?').run(qrDataURL, participantId);
    
    res.json({ 
      qr_code: qrDataURL, 
      unique_code: participant.unique_code,
      name: participant.name 
    });
  } catch (err) {
    res.status(500).json({ error: 'خطأ في إنشاء QR' });
  }
});

// Generate QR for all participants (leaders only)
router.post('/generate-all', authMiddleware, leaderOnly, async (req, res) => {
  const db = getDB();
  const participants = db.prepare('SELECT * FROM participants').all();
  
  const results = [];
  for (const p of participants) {
    const qrData = JSON.stringify({ code: p.unique_code, name: p.name, id: p.id });
    const qrDataURL = await QRCode.toDataURL(qrData, { width: 250, margin: 2 });
    db.prepare('UPDATE participants SET qr_code = ? WHERE id = ?').run(qrDataURL, p.id);
    results.push({ id: p.id, name: p.name, qr_code: qrDataURL });
  }
  
  res.json({ success: true, count: results.length, participants: results });
});

module.exports = router;
