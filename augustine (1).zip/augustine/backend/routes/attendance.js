const router = require('express').Router();
const { getDB } = require('../db');
const { authMiddleware, leaderOnly } = require('../middleware/auth');

function calculateAttendancePoints(timeStr) {
  // timeStr format: "HH:MM"
  const [hours, minutes] = timeStr.split(':').map(Number);
  const totalMinutes = hours * 60 + minutes;
  
  // 5:00 = 300 min, 5:10 = 310 min, 5:30 = 330 min
  const t500 = 17 * 60; // 5:00 PM = 17:00
  const t510 = 17 * 60 + 10;
  const t530 = 17 * 60 + 30;
  
  if (totalMinutes <= t510) return 20;
  if (totalMinutes <= t530) return 5;
  return 1;
}

// Scan QR code / record attendance
router.post('/scan', (req, res) => {
  const { unique_code } = req.body;
  if (!unique_code) return res.status(400).json({ error: 'الكود مطلوب' });
  
  const db = getDB();
  const participant = db.prepare('SELECT * FROM participants WHERE unique_code = ?').get(unique_code.trim());
  if (!participant) return res.status(404).json({ error: 'المشترك غير موجود' });
  
  const now = new Date();
  const date = now.toISOString().split('T')[0];
  const time = now.toTimeString().slice(0, 5); // HH:MM
  
  // Check if already attended today
  const existing = db.prepare(
    'SELECT * FROM attendance WHERE participant_id = ? AND date = ?'
  ).get(participant.id, date);
  
  if (existing) {
    return res.status(409).json({ 
      error: 'تم تسجيل الحضور مسبقاً اليوم',
      participant: { name: participant.name },
      attendance: existing
    });
  }
  
  const points = calculateAttendancePoints(time);
  
  // Record attendance in transaction
  const recordAttendance = db.transaction(() => {
    db.prepare(
      'INSERT INTO attendance (participant_id, date, time, points) VALUES (?, ?, ?, ?)'
    ).run(participant.id, date, time, points);
    
    db.prepare(
      'UPDATE participants SET total_points = total_points + ?, attendance_points = attendance_points + ? WHERE id = ?'
    ).run(points, points, participant.id);
    
    db.prepare(
      'INSERT INTO points_log (participant_id, type, points_change, date) VALUES (?, ?, ?, ?)'
    ).run(participant.id, 'attendance', points, date);
  });
  
  recordAttendance();
  
  const updatedParticipant = db.prepare('SELECT * FROM participants WHERE id = ?').get(participant.id);
  
  res.json({
    success: true,
    participant: { name: updatedParticipant.name, total_points: updatedParticipant.total_points },
    attendance: { date, time, points },
    message: `تم تسجيل حضور ${updatedParticipant.name} - ${points} نقطة`
  });
});

// Get all attendance (leaders only)
router.get('/', authMiddleware, leaderOnly, (req, res) => {
  const db = getDB();
  const { date } = req.query;
  
  let query = `
    SELECT a.*, p.name as participant_name 
    FROM attendance a 
    JOIN participants p ON a.participant_id = p.id
  `;
  const params = [];
  
  if (date) {
    query += ' WHERE a.date = ?';
    params.push(date);
  }
  
  query += ' ORDER BY a.date DESC, a.time DESC LIMIT 100';
  const records = db.prepare(query).all(...params);
  res.json(records);
});

module.exports = router;
