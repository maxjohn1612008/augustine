const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const path = require('path');

const DB_PATH = path.join(__dirname, 'augustine.db');
const db = new Database(DB_PATH);

// Enable WAL mode for better performance
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Create tables
db.exec(`
  CREATE TABLE IF NOT EXISTS leaders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS participants (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    unique_code TEXT UNIQUE NOT NULL,
    qr_code TEXT,
    total_points INTEGER DEFAULT 0,
    attendance_points INTEGER DEFAULT 0,
    mass_points INTEGER DEFAULT 0,
    confession_points INTEGER DEFAULT 0,
    meeting_points INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    participant_id INTEGER NOT NULL,
    date TEXT NOT NULL,
    time TEXT NOT NULL,
    points INTEGER NOT NULL,
    FOREIGN KEY (participant_id) REFERENCES participants(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS points_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    participant_id INTEGER NOT NULL,
    type TEXT NOT NULL CHECK(type IN ('attendance','mass','confession','meeting','manual_add','manual_subtract')),
    points_change INTEGER NOT NULL,
    notes TEXT,
    leader_id INTEGER,
    date TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (participant_id) REFERENCES participants(id) ON DELETE CASCADE,
    FOREIGN KEY (leader_id) REFERENCES leaders(id)
  );
`);

// Create default admin leader
const adminExists = db.prepare('SELECT id FROM leaders WHERE username = ?').get('admin');
if (!adminExists) {
  const hashedPassword = bcrypt.hashSync('admin123', 12);
  db.prepare('INSERT INTO leaders (username, password, name) VALUES (?, ?, ?)').run('admin', hashedPassword, 'المشرف الرئيسي');
  console.log('✅ Default admin created: username=admin, password=admin123');
}

// Create some sample participants for testing
const sampleCount = db.prepare('SELECT COUNT(*) as cnt FROM participants').get();
if (sampleCount.cnt === 0) {
  const sampleParticipants = [
    { name: 'يوحنا مرقس', code: uuidv4() },
    { name: 'مريم الجديدة', code: uuidv4() },
    { name: 'بطرس الرسول', code: uuidv4() },
  ];
  
  const insert = db.prepare('INSERT INTO participants (name, unique_code, total_points) VALUES (?, ?, ?)');
  sampleParticipants.forEach(p => insert.run(p.name, p.code, 0));
  console.log('✅ Sample participants created');
}

console.log('✅ Database initialized successfully at:', DB_PATH);
db.close();
