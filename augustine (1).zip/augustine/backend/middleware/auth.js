const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET || 'augustine_secret_key_2024';

function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'غير مصرح' });
  
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: 'جلسة منتهية' });
  }
}

function leaderOnly(req, res, next) {
  if (req.user?.role !== 'leader') return res.status(403).json({ error: 'للخدام فقط' });
  next();
}

module.exports = { authMiddleware, leaderOnly, JWT_SECRET };
