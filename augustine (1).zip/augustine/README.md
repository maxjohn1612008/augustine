# ✝️ أوغسطين — Augustine Attendance & Points System

نظام متكامل لإدارة الحضور والنقاط باللغة العربية.

---

## 🚀 التثبيت والتشغيل

### المتطلبات
- Node.js v18 أو أحدث
- npm

### 1. تثبيت الحزم

```bash
cd backend
npm install
```

### 2. تهيئة قاعدة البيانات

```bash
npm run init-db
```

يقوم هذا بإنشاء:
- قاعدة البيانات `augustine.db`
- حساب الإدارة الافتراضي: **username: `admin`** / **password: `admin123`**
- 3 مشتركين تجريبيين

### 3. تشغيل الخادم

```bash
npm start
```

أو للتطوير مع إعادة التشغيل التلقائي:
```bash
npm run dev
```

افتح المتصفح على: **http://localhost:3001**

---

## 📁 هيكل المشروع

```
augustine/
├── backend/
│   ├── server.js          # الخادم الرئيسي
│   ├── db.js              # اتصال قاعدة البيانات
│   ├── initDB.js          # تهيئة قاعدة البيانات
│   ├── package.json
│   ├── middleware/
│   │   └── auth.js        # JWT authentication
│   └── routes/
│       ├── auth.js        # تسجيل الدخول والخروج
│       ├── participants.js # إدارة المشتركين
│       ├── leaders.js     # إدارة الخدام
│       ├── attendance.js  # نظام الحضور
│       ├── points.js      # نظام النقاط
│       └── qr.js          # توليد QR
└── frontend/
    ├── index.html
    ├── css/
    │   └── main.css
    └── js/
        ├── api.js
        ├── auth.js
        ├── utils.js
        ├── app.js
        └── pages/
            ├── login.js
            ├── leader.js
            ├── participant.js
            └── scan.js
```

---

## 👑 صلاحيات الخادم (Leader)

| الوظيفة | متاح |
|---------|------|
| إضافة/حذف مشتركين | ✅ |
| تعديل بيانات المشتركين | ✅ |
| إضافة/خصم نقاط | ✅ |
| إضافة خدام جدد | ✅ |
| عرض جميع البيانات | ✅ |
| توليد وطباعة QR | ✅ |
| سجل الحضور | ✅ |
| مسح QR لتسجيل الحضور | ✅ |

## 👤 صلاحيات المخدوم (Participant)

| الوظيفة | متاح |
|---------|------|
| عرض نقاطه الكلية | ✅ |
| تفصيل النقاط (حضور/قداس/اعتراف/اجتماع) | ✅ |
| سجل الحضور | ✅ |
| QR code خاص به | ✅ |
| تعديل أي بيانات | ❌ |

---

## ⏰ نظام نقاط الحضور

| وقت الحضور | النقاط |
|------------|--------|
| ٥:٠٠ → ٥:١٠ مساءً | 20 نقطة |
| ٥:١٠ → ٥:٣٠ مساءً | 5 نقاط |
| بعد ٥:٣٠ مساءً | 1 نقطة |

---

## 🔌 API Endpoints

### Auth
```
POST /api/auth/login/leader      # دخول الخادم
POST /api/auth/login/participant # دخول المخدوم
GET  /api/auth/verify            # التحقق من Token
```

### Participants
```
GET    /api/participants          # قائمة المشتركين
GET    /api/participants/:id      # بيانات مشترك
POST   /api/participants          # إضافة مشترك
PUT    /api/participants/:id      # تعديل مشترك
DELETE /api/participants/:id      # حذف مشترك
GET    /api/participants/:id/attendance  # سجل الحضور
GET    /api/participants/:id/points-log # سجل النقاط
```

### Attendance
```
POST /api/attendance/scan        # مسح QR (عام)
GET  /api/attendance             # سجل الحضور (خدام)
```

### Points
```
POST /api/points/update          # تحديث النقاط
GET  /api/points/leaderboard     # لوحة المتصدرين
```

### QR
```
GET  /api/qr/:id                 # QR لمشترك
POST /api/qr/generate-all        # توليد الكل
```

---

## 🔐 الأمان

- كلمات المرور محمية بـ bcrypt (12 rounds)
- JWT tokens تنتهي بعد 8 ساعات (للخدام) و24 ساعة (للمشتركين)
- مسارات محمية حسب الدور
- Rate limiting على جميع API endpoints

---

## 🌐 النشر على الإنترنت

### Railway (مجاني)
```bash
# 1. ارفع المشروع على GitHub
# 2. اربطه بـ Railway.app
# 3. Set start command: cd backend && npm install && npm run init-db && npm start
```

### Render
```bash
# Build command: cd backend && npm install && node initDB.js
# Start command: cd backend && node server.js
```

### متغيرات البيئة
```env
PORT=3001
JWT_SECRET=your_strong_secret_key_here
NODE_ENV=production
```

---

## 📱 استخدام QR Scanner

يمكن استخدام أي تطبيق QR Scanner لمسح الأكواد:

1. افتح صفحة **"مسح QR"** على جهاز الخادم
2. امسح QR code المشترك باستخدام كاميرا الهاتف أو scanner خارجي
3. سيتم تسجيل الحضور تلقائياً مع النقاط المناسبة

---

## 💡 نصائح

- غيّر كلمة مرور `admin` فوراً بعد أول تشغيل
- احتفظ بنسخة احتياطية من `augustine.db` بانتظام
- استخدم HTTPS في الإنتاج لحماية البيانات
