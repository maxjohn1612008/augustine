#!/bin/bash
echo "🚀 تثبيت نظام أوغسطين..."
cd backend
npm install
echo "✅ تم تثبيت الحزم"
node initDB.js
echo "✅ تم تهيئة قاعدة البيانات"
echo ""
echo "🎉 اكتمل التثبيت!"
echo "👉 لتشغيل الخادم: cd backend && npm start"
echo "👉 ثم افتح: http://localhost:3001"
echo ""
echo "🔑 بيانات الدخول الافتراضية:"
echo "   الخادم:  username=admin  password=admin123"
